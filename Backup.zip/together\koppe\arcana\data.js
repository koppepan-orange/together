let arcanas = [
    {
        name: "The Fool",
        draed: 0,
        img: "fool.png",
        able:1
    },
    {
        name: "The Magician",
        draed: 0,
        img: "magician.png",
        able:0
    },
    {
        name: "The High Priestess",
        draed: 0,
        img: "high_priestess.png",
        able:0
    },
    {
        name: "The Empress",
        draed: 0,
        img: "empress.png",
        able:1
    },
    {
        name: "The Emperor",
        draed: 0,
        img: "emperor.png",
        able:1
    },
    {
        name: "The Hierophant",
        draed: 0,
        img: "hierophant.png",
        able:0
    },
    {
        name: "The Lovers",
        draed: 0,
        img: "lovers.png",
        able:0
    },
    {
        name: "The Chariot",
        draed: 0,
        img: "chariot.png",
        able:0
    },
    {
        name: "Strength",
        draed: 0,
        img: "strength.png",
        able:1
    },
    {
        name: "The Hermit",
        draed: 0,
        img: "hermit.png",
        able:1
    },
    {
        name: "Wheel of Fortune",
        draed: 0,
        img: "wheel_of_fortune.png",
        able:1
    },
    {
        name: "Justice",
        draed: 0,
        img: "justice.png",
        able:1
    },
    {
        name: "The Hanged Man",
        draed: 0,
        img: "hanged_man.png",
        able:0
    },
    {
        name: "Death",
        draed: 0,
        img: "death.png",
        able:1
    },
    {
        name: "Temperance",
        draed: 0,
        img: "temperance.png",
        able:0
    },
    {
        name: "The Devil",
        draed: 0,
        img: "devil.png",
        able:0
    },
    {
        name: "The Tower",
        draed: 0,
        img: "tower.png",
        able:0
    },
    {
        name: "The Star",
        draed: 0,
        img: "star.png",
        able:0
    },
    {
        name: "The Moon",
        draed: 0,
        img: "moon.png",
        able:0
    },
    {
        name: "The Sun",
        draed: 0,
        img: "sun.png",
        able:0
    },
    {
        name: "Judgement",
        draed: 0,
        img: "judgement.png",
        able:0
    },
    {
        name: "The World",
        draed: 0,
        img: "world.png",
        able:0
    }
]